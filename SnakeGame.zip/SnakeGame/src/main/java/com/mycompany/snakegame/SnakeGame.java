import java.util.*;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Graphics;
import javax.swing.*;
import java.util.Random;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.mycompany.snakegame;

/**
 *
 * @author DELL
 */
public class SnakeGame {
    public static void main(String[] args)
	{
		new GameFrame();
		
	}
    
}




